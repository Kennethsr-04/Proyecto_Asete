<?php
$password = "pedro"; 
$hash = hash("sha256", $password . "SALT123");
echo $hash;
?>
