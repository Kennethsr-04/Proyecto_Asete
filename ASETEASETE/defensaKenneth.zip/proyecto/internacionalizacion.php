<?php

    $lang = $_SESSION["idioma"] ?? "es";

    if($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["idioma"])){
        $lang = $_GET["idioma"] ?? "es";
    }

    $file = "lang/$lang.php";

    if (file_exists($file)) {
        require $file;
    } else {
        require "lang/es.php";
    }
	
?>