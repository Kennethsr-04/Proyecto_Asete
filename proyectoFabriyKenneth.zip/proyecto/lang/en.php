<?php
	$traducciones = [
		"login" => "Login",
		"user" => "User",
		"pass" => "Password",
		"enter" => "Enter",
		"catalog" => "Movie catalog",
		"filter" => "Movie filter",
		"logout" => "Logout",
		"new_film" => "New Film",
		"title" => "Title",
		"year" => "Year",
		"director" => "Director",
		"actors" => "Actors",
		"genre" => "Genre",
		"seassons" => "Seassons",
		"duration" => "Duration",
		"save_film" => "Save film",
		"add_new_film" => "Add new film",
		"back_to_catalog" => "Back to catalog"
	];
?>