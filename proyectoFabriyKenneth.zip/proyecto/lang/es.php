<?php
	$traducciones = [
		"login" => "Inicio de sesión",
		"user" => "Usuario",
		"pass" => "Contraseña",
		"enter" => "Entrar",
		"catalog" => "Catálogo de películas",
		"filter" => "Filtro de películas",
		"logout" => "Cerrar sesión",
		"new_film" => "Nueva película",
		"title" => "Título",
		"year" => "Año",
		"director" => "Director",
		"actors" => "Actores",
		"genre" => "Género",
		"seassons" => "Temporadas",
		"duration" => "Duración",
		"save_film" => "Guardar película",
		"add_new_film" => "Agregar nueva película",
		"back_to_catalog" => "Volver al catálogo"
	];
?>